public interface CommandArgs extends java.io.Serializable
{
    public void execute(Object o);
}
