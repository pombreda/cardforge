import java.util.*;

public class CardUtil
{
  public final static Random r = new Random();

  //checks to see if the card can produce mana
  //presumes mana abilities start with "tap: add"
  public static boolean isMana(Card c)
  {
    Object[] keyword = c.getKeyword().toArray();

    for(int i = 0; i < keyword.length; i++)
      if(keyword[i].toString().startsWith("tap: add"))
        return true;

    return false;
  }

  public static int getRandomIndex(Object[] o)
  {
    if(o == null || o.length == 0)
      throw new RuntimeException("CardUtil : getRandomIndex() argument is null or length is 0");

    return r.nextInt(o.length);
  }
  public static Card getRandom(Card[] o)
  {
    return o[getRandomIndex(o)];
  }
  public static int getRandomIndex(SpellAbilityList list)
  {
    if(list == null || list.size() == 0)
      throw new RuntimeException("CardUtil : getRandomIndex(SpellAbilityList) argument is null or length is 0");

    return r.nextInt(list.size());
  }
  public static int getRandomIndex(CardList c)
      {return r.nextInt(c.size());}

  //returns Card Name (unique number) attack/defense
  //example: Big Elf (12) 2/3
  public static String toText(Card c)
  {
    return c.getName() +" (" +c.getUniqueNumber() +") " +c.getAttack() +"/" +c.getDefense();
  }
  public static Card[] toCard(Collection col)
  {
    Object o[] = col.toArray();
    Card c[] = new Card[o.length];

    for(int i = 0; i < c.length; i++)
    {
      Object swap = o[i];
      if(swap instanceof Card)
        c[i] = (Card)o[i];
      else
        throw new RuntimeException("CardUtil : toCard() invalid class, should be Card - " +o[i].getClass() +" - toString() - " +o[i].toString());
    }

    return c;
  }
  public static Card[] toCard(ArrayList list)
  {
    Card[] c = new Card[list.size()];
    list.toArray(c);
    return c;
  }
  public static ArrayList toList(Card c[])
  {
    ArrayList a = new ArrayList();
    for(int i = 0; i < c.length; i++)
      a.add(c[i]);
    return a;
  }
  //returns "G", longColor is Constant.Color.Green and the like
  public static String getShortColor(String longColor)
  {
    Map map = new HashMap();
    map.put(Constant.Color.Black, "B");
    map.put(Constant.Color.Blue , "U");
    map.put(Constant.Color.Green, "G");
    map.put(Constant.Color.Red  , "R");
    map.put(Constant.Color.White, "W");

    Object o = map.get(longColor);
    if(o == null)
      throw new RuntimeException("CardUtil : getShortColor() invalid argument - " +longColor);

    return (String)o;
  }


  //returns something like Constant.Color.Green or something
  public static String getColor(Card c)
  {
    String manaCost = c.getManaCost();

    if(-1 != manaCost.indexOf("G"))
      return Constant.Color.Green;
    else if(-1 != manaCost.indexOf("W"))
      return Constant.Color.White;
    else if(-1 != manaCost.indexOf("B"))
      return Constant.Color.Black;
    else if(-1 != manaCost.indexOf("U"))
      return Constant.Color.Blue;
    else if(-1 != manaCost.indexOf("R"))
      return Constant.Color.Red;
    else
      return Constant.Color.Colorless;
  }
  public static ArrayList getColors(Card c)
  {
    String m = c.getManaCost();
    Set colors = new HashSet();

    for(int i = 0; i < m.length(); i++)
    {
      switch(m.charAt(i))
    {
      case ' ': break;
      case 'G': colors.add(Constant.Color.Green); break;
      case 'W': colors.add(Constant.Color.White); break;
      case 'B': colors.add(Constant.Color.Black); break;
      case 'U': colors.add(Constant.Color.Blue); break;
      case 'R': colors.add(Constant.Color.Red); break;
    }
    }
    if(colors.isEmpty())
      colors.add(Constant.Color.Colorless);

    return new ArrayList(colors);
  }
  public static boolean hasCardName(String cardName, ArrayList list)
  {
    Card c;
    boolean b = false;

    for(int i = 0; i < list.size(); i++)
    {
      c = (Card)list.get(i);
      if(c.getName().equals(cardName))
      {
        b = true;
        break;
      }
    }
    return b;
  }//hasCardName()

  //probably should put this somewhere else, but not sure where
  static public int getConvertedManaCost(SpellAbility sa)
  {
    return getConvertedManaCost(sa.getManaCost());
  }

  static public int getConvertedManaCost(String manaCost)
  {
    //see if the mana cost is all colorless, like "2", "0", or "12"

    if(manaCost.equals(""))
      return 0;

    try{
      return Integer.parseInt(manaCost);
    }
    catch(NumberFormatException ex) {}

    //see if mana cost is colored and colorless like "2 B" or "1 U U"
    StringTokenizer tok = new StringTokenizer(manaCost);
    int cost = 0;
    try{
      //get the int from the mana cost like "1 U", get the 1
      cost = Integer.parseInt(tok.nextToken());
      //count colored mana cost
      cost += tok.countTokens();
      return cost;
    }
    //catches in case the cost has no colorless mana requirements like "U U"
    catch(NumberFormatException ex) {}

    //the mana cost is all colored mana like "U" or "B B B"
    tok = new StringTokenizer(manaCost);
    return tok.countTokens();
  }
}