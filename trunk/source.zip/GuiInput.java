import java.util.*;

public class GuiInput extends MyObservable implements Observer 
{
    private Input input;
    
    public GuiInput()
    {
	AllZone.InputControl.addObserver(this);
	AllZone.Stack.addObserver(this);
	AllZone.Phase.addObserver(this);
    }    
    public void update(Observable observable, Object obj)
    {
	setInput(AllZone.InputControl.getInput());
    }        
    private void setInput(Input in) 
    {
	input = in;
	input.showMessage();
    }
    
    public void showMessage()           {input.showMessage();}
    public void selectButtonOK()      {input.selectButtonOK();}
    public void selectButtonCancel(){input.selectButtonCancel();}
    
    public void selectPlayer(String player)                   {input.selectPlayer(player);}
    public void selectCard(Card card, PlayerZone zone) {input.selectCard(card, zone);}
    
    public String toString(){return input.toString();}
}