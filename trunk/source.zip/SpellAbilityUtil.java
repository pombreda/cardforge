import java.util.*;

public class SpellAbilityUtil
{   
    //only works for MONO-COLORED spells
    static public UndoCommand getPayCostCommand(final String player, final String manaCost)
    {
	return new UndoCommand()
	{
	    private CardList tapped = new CardList();
	    public void execute()
	    {
		tapped.clear();
		
		int n = CardUtil.getConvertedManaCost(manaCost);
		CardList mana = getAvailableMana(player);
		if(mana.size() < n)
		    throw new RuntimeException("SpellAbilityUtil : payCost() error, not enough mana, trying to pay for the mana cost " +manaCost +" , player " +player);

		for(int i = 0; i < n; i++)
		{
		    mana.get(i).tap();	
		    tapped.add(mana.get(i));
		}
	    }
	    public void undo()
	    {
		for(int i = 0; i < tapped.size(); i++)
		    tapped.get(i).untap();

		tapped.clear();	    
	    }
	};//UndoCommand
    }//payCost()
    
    static public CardList getAvailableMana(String player)
    {
	PlayerZone play = AllZone.getZone(Constant.Zone.Play, player);
	CardList all = new CardList(play.getCards());
	CardList mana = all.filter(new CardListFilter()
	{
	    public boolean addCard(Card c)
	    {
		if(c.isTapped())
		    return false;
		
		ArrayList a = c.getKeyword();
		for(int i = 0; i < a.size(); i++)
		    if(a.get(i).toString().startsWith("tap: add"))
			return true;
		
		return false;
	    }//addCard()
	});//CardListFilter
	
	return mana;
    }//getUntappedMana     
    public static boolean canPlaySpell(Card c) {return Spell.canPlay(c);}
}