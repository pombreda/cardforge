import java.util.*;

public class GenerateSealedDeck
{
  private String color1;
  private String color2;

  private Map map = new HashMap();

  public GenerateSealedDeck() {setupMap();}

  private void setupMap()
  {
    map.put(Constant.Color.Black , "Swamp");
    map.put(Constant.Color.Blue  , "Island");
    map.put(Constant.Color.Green , "Forest");
    map.put(Constant.Color.Red   , "Mountain");
    map.put(Constant.Color.White , "Plains");
  }

  public CardList generateDeck()
  {
    CardList deck;
    do{
      deck = get2ColorDeck();
    }while(deck.getType("Creature").size() < 12 || 16 < deck.getType("Creature").size());

    addLand(deck);

    if(deck.size() != 40)
      throw new RuntimeException("GenerateSealedDeck() : generateDeck() error, deck size it not 40, deck size is " +deck.size());

    return deck;
  }
  private void addLand(CardList list)
  {
    Card land;
    for(int i = 0; i < 9; i++)
    {
      land = AllZone.CardFactory.getCard(map.get(color1).toString(), Constant.Player.Computer);
      list.add(land);

      land = AllZone.CardFactory.getCard(map.get(color2).toString(), Constant.Player.Computer);
      list.add(land);
    }
  }//addLand()
  private CardList get2ColorDeck()
  {
    ReadBoosterPack booster = new ReadBoosterPack();
    CardList deck;
    do{
      deck = get2Colors(booster.getBoosterPack5());
    }while(deck.size() < 22);

    CardList out = new CardList();
    deck.shuffle();

    //trim deck size down to 22 cards, presumes 18 land
    for(int i = 0; i < 22 && i < deck.size(); i++)
      out.add(deck.get(i));

    return out;
  }
  private CardList get2Colors(CardList in)
  {
    int a;
    int b;

    do{
      a = CardUtil.getRandomIndex(Constant.Color.onlyColors);
      b = CardUtil.getRandomIndex(Constant.Color.onlyColors);
    }while(a == b);//do not want to get the same color twice

    color1 = Constant.Color.onlyColors[a];
    color2 = Constant.Color.onlyColors[b];

    CardList out = new CardList();
    out.addAll(CardListUtil.getColor(in, color1).toArray());
    out.addAll(CardListUtil.getColor(in, color2).toArray());

    CardList artifact = in.filter(new CardListFilter()
    {
      public boolean addCard(Card c)
      {
        return c.isArtifact();
      }
    });

    out.addAll(artifact.toArray());

    out = filterBadCards(out);

    return out;
  }
  private CardList filterBadCards(CardList list)
  {
    //remove "bad" and multi-colored cards
    final ArrayList remove = new ArrayList();
    remove.add("Force of Savagery");
    remove.add("Darksteel Colossus");
    remove.add("Jokulhaups");
    remove.add("Steel Wall");
    remove.add("Ornithopter");
    remove.add("Sarcomite Myr");

    CardList out = list.filter(new CardListFilter()
    {
      public boolean addCard(Card c)
      {
        return CardUtil.getColors(c).size() == 1 && !remove.contains(c.getName());
      }
    });

    return out;
  }//filterBadCards()
  public static void main(String[] args)
  {
    GenerateSealedDeck g = new GenerateSealedDeck();

    for(int i = 0; i < 100; i++)
    {
      System.out.println(i);
      g.generateDeck();
    }

/*
    for(int i = 0; i < 10; i++)
    {
      CardList c = g.generateDeck();
      System.out.println(c.getType("Creature").size());
    }
*/
  }
}