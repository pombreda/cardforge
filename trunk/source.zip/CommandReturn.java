public interface CommandReturn
{
  public Object execute();
}