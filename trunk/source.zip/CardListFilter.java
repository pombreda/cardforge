public interface CardListFilter
{
    public boolean addCard(Card c);
}
