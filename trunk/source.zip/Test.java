import java.util.*;

import javax.swing.*;
import javax.swing.plaf.*;

class Test
{
  public static void main(String[] args)
  {


    System.exit(0);
  }
}
