//only SpellAbility can go on the stack
//override any methods as needed
public abstract class SpellAbility
{
  //choices for constructor isPermanent argument
  public static final int Spell = 0;
  public static final int Ability = 1;
  public static final int Ability_Tap = 2;

  private String description        = "";
  private String targetPlayer       = "";
  private String stackDescription = "";
  private String manaCost          = "";

  private Card targetCard;
  private Card sourceCard;

  private boolean spell;
  private boolean tapAbility;

  private Input beforePayMana;
  private Input afterResolve;
  private Input afterPayMana;

  private CommandArgs randomTarget = new CommandArgs() {public void execute(Object o) {}};

  public SpellAbility(int spellOrAbility, Card i_sourceCard)
  {
    if(spellOrAbility == Spell)
      spell = true;
    else if(spellOrAbility ==Ability)
      spell = false;
    else if(spellOrAbility == Ability_Tap)
    {
      spell        = false;
      tapAbility = true;
    }
    else
      throw new RuntimeException("SpellAbility : constructor error, invalid spellOrAbility argument = " +spellOrAbility);

    sourceCard = i_sourceCard;
  }
  //Spell, and Ability, and other Ability objects override this method
  abstract public boolean canPlay();

  //all Spell's and Abilities must override this method
  abstract public void resolve();

/*
  public boolean canPlayAI()
  {
    return true;
  }
  public void chooseTargetAI()
  {

  }
*/
  public boolean canPlayAI() {return true;}

  public void        chooseTargetAI()                 {randomTarget.execute(this);}
  public void        setChooseTargetAI(CommandArgs c) {randomTarget = c;}
  public CommandArgs getChooseTargetAI()              {return randomTarget;}

  public String getManaCost()                {return manaCost;}
  public void   setManaCost(String cost) {manaCost = cost;}

  public boolean isSpell()        {return spell; }
  public boolean isAbility()     {return ! isSpell(); }
  public boolean isTapAbility() {return tapAbility;}

  public Card getSourceCard()  {return sourceCard;}

  //begin - Input methods
  public Input getBeforePayMana()            {return beforePayMana;}
  public void  setBeforePayMana(Input in) {beforePayMana = in; }

  public Input getAfterPayMana()            {return afterPayMana;}
  public void  setAfterPayMana(Input in) {afterPayMana = in;}

  public Input getAfterResolve()             {return afterResolve;}
  public void setAfterResolve (Input in)  {afterResolve = in;}

  public void setStackDescription(String s) {stackDescription = s;}
  public String getStackDescription()
  {
    if(stackDescription.equals(getSourceCard().getText().trim()))
      return getSourceCard().getName() +" - " +getSourceCard().getText();

    return stackDescription;
  }

  //setDescription() includes mana cost and everything like
  //"G, tap: put target creature from your hand into play"
  public void setDescription(String s)  {description = s;}
  public String toString()                     {return description;}

  public Card getTargetCard()
  {
    if(targetCard == null)
      return null;

    return targetCard;
  }
  public void setTargetCard(Card card)
  {
    targetPlayer = null;//reset setTargetPlayer()

    targetCard = card;
    setStackDescription(getSourceCard().getName() +" - targeting " +card);
  }
  public void setTargetPlayer(String p)
  {
    targetCard = null;//reset setTargetCard()

    if(p == null || (!(p.equals(Constant.Player.Human) || p.equals(Constant.Player.Computer))))
      throw new RuntimeException("SpellAbility : setTargetPlayer() error, argument is " +p  +" source card is " +getSourceCard());
    targetPlayer = p;
    setStackDescription(getSourceCard().getName() +" - targeting " +p);
  }
  public String getTargetPlayer()            {return targetPlayer;}
}