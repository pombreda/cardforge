import java.util.*;
import java.io.*;

class TempRun
{
  public static void main(String[] args)
  {
//    CardFactory cf = AllZone.CardFactory;

    for(int i = 0; i < 10; i++)
      System.out.println(MyRandom.percentTrue(10));


    System.exit(0);
  }//main
}